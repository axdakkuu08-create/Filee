# Filee Android: Phase 1 compatibility audit (read-only)

- Repository: axdakkuu08-create/filee (fork of KnifeLemon/Filee, MIT)
- Baseline: `main` @ `79f03bea1b93588002940812c45a7b8702a9a9f0` (matches the blueprint's recorded SHA)
- Working tree: read-only shallow clone, `GIT_LFS_SKIP_SMUDGE=1`. LFS-tracked files are pointer stubs here.
- Repository modifications: none. No commits, no branches pushed.

## 1. Environment limits (affects what can be verified)

| Item | Status |
| --- | --- |
| .NET SDK 10.0.100 (`global.json`) | Not installed in this environment |
| Android SDK / `android` workload | Not installed (`ANDROID_HOME` unset) |
| Package downloads (NuGet, npm, pip) | Blocked for this account |
| Physical Android device | Not available |

Consequence: nothing in `src/Filee.Mobile/` has been compiled, run, or tested. Build, test, and APK claims are pending until they are run on a machine with the toolchain.

## 2. Repository structure

| Project | Role | Mobile reuse |
| --- | --- | --- |
| `Filee.Core` | Formats, presets, job queue, settings, conversion pipeline | Candidate. Contains 4 Avalonia mentions, all in comments. No Avalonia package reference. |
| `Filee.Engines` | 60+ converter families and native/external engine runners | Mixed. See section 4. |
| `Filee.App` | Avalonia desktop UI, tray, donut toolbar, global hooks, local web server (Kestrel) | Desktop-only. Not reused. |
| `Filee.Platform.Windows` / `.Linux` / `.MacOS` | OS services | Desktop-only. Android implementations needed. |
| `Filee.Cli`, `Filee.Setup` | CLI and installer | Not in scope. |
| `tests/*` | Desktop test projects | Regression only. |

Avalonia version: 12.1.4 (central package management in `Directory.Packages.props`).

## 3. Coupling findings

- `Filee.Core`: 1 file starts an external process. This is the job-runner boundary and should be abstracted behind an interface before Android.
- `Filee.Engines`: 5 files use `ProcessStartInfo` or `ProcessRunner` (`Infrastructure/ProcessRunner.cs`, `Infrastructure/EngineInstaller.cs`, `Infrastructure/CopyVersions.cs`, `Media/FfmpegRunner.cs`, `Media/ClipPreview.cs`). Android apps cannot spawn these binaries.
- `Filee.Core` declares `IPlatformServices`, `MarkOfTheWeb`, `ShortcutFolders`, `WorkFolders`, `FileSystemPaths`. These are the platform seams to implement for Android (SAF, app-private storage).
- Desktop-only in the App: `SharpHook` global hooks, tray service, donut toolbar, Explorer/Finder integration, the Kestrel-based Connect server, and Wayland packages.

## 4. Engine compatibility matrix (Section 5 of the blueprint)

Classification per blueprint: **A** verified on Android, **B** adaptation required, **C** replacement required, **D** unsupported for now.

No engine has been verified on Android. The "Expected" column is based on package type only.

| Engine / package | Type | Formats (from repo) | Expected | Notes |
| --- | --- | --- | --- | --- |
| Markdig | Managed | Markdown | B (likely A) | Pure .NET; verify on Android runtime |
| PDFsharp | Managed | PDF manipulation | B (likely A) | Verify |
| PdfPig | Managed | PDF text read | B (likely A) | Verify |
| ExcelDataReader, ExcelNumberFormat | Managed | XLS/XLSX read | B (likely A) | Verify |
| SharpCompress | Managed | Archives | B (likely A) | Verify |
| MimeKitLite, MsgReader | Managed | Email | B (likely A) | Verify |
| AngleSharp, YamlDotNet, Tomlyn | Managed | HTML/YAML/TOML | B (likely A) | Verify |
| ACadSharp, SharpGLTF, System.Formats.Nrbf | Managed | CAD, glTF, .NET binary | B | Verify |
| LTRData.DiscUtils (ISO, UDF) | Managed | Disc images | B (likely A) | Verify |
| Magick.NET-Q8-AnyCPU | Native (ImageMagick) | Image conversion | B | Needs Android native build for arm64; check package support |
| SkiaSharp, Svg.Skia | Native (Skia) | Vector and SVG | B | Android native builds exist; confirm version |
| PDFtoImage | Native (PDFium) | PDF to image | B | Confirm Android PDFium binary |
| Unhwp | Native | HWP/HWPX | C | Repo already builds custom native for linux-arm64 and win-arm64. Android needs its own build (`build/build-native.py` covers only desktop targets). |
| rhwp 0.8.7 | External Windows exe | HWP | C | Windows zip only |
| pandoc 3.13 | External Windows exe | Document formats | C | No Android build in manifest |
| LibreOffice 26.2.6 | External Windows MSI (~373 MB) | Office formats | D | Not feasible on Android; no Android pinned build |
| h2orestart 0.8.0 | LibreOffice extension | Legacy formats | D | Depends on LibreOffice |
| ghostscript 10.08.0 | Windows conda | PostScript, PDF raster | C | No Android build |
| ffmpeg 9.1 | Windows shared build | Audio and video | C (separate integration) | Blueprint requires ABI and licence check. Windows-only today. |
| whisper.cpp b5454 + model | Windows exe | Speech to text | C | Blueprint defers. Native Android build would be a separate project. |
| tesseract 5.4 (+ language data) | Windows NSIS installer | OCR | C | Android native build needed |
| calibre 9.17.0 | Windows MSI | E-books | D | Large; no Android build |
| weasyprint 70.0 | Windows onedir | HTML to PDF | C | Python-based; no Android build |
| exiftool 13.60 | Windows zip (Perl) | Metadata | C | Needs Perl runtime on Android; treat as D |
| upscayl-bin | Windows zip (ncnn) | AI upscale | C | ncnn has Android builds; needs integration |
| 7zip 26.05 | Windows MSI | Archives | C | Replace with SharpCompress on Android |
| Temurin JRE 21 | Windows zip | Java-based engines | D | Not needed on Android if the consuming engine is replaced |
| vcruntime, vcomp14 | Windows conda | Runtime DLLs | D | Windows-only; not applicable |

Summary: the managed-only candidates are the cheapest path. The first slice should use managed or Android-native image and PDF engines, with external-executable engines moved to a later phase.

## 5. Licensing and redistribution (initial, not legal advice)

- Project: MIT (Copyright 2026 Myeonggu Kim and contributors).
- External engines carry their own licences (LibreOffice MPL-2.0, Ghostscript AGPL or commercial, FFmpeg LGPL/GPL depending on build, Pandoc GPL-2.0, Tesseract Apache-2.0, whisper.cpp MIT, calibre GPL-3.0, ExifTool Artistic/GPL). Redistribution in an APK requires a per-engine review before release.
- `THIRD-PARTY-NOTICES.md` exists in the repo and must be extended for Android.
- Note that GPL and AGPL components are a problem for a closed or store-distributed APK unless their licences allow it.

## 6. Build and tooling notes

- `Directory.Packages.props` uses central package management. The mobile project must either add its packages there or disable central management locally. `src/Filee.Mobile/Filee.Mobile.csproj` disables it locally, to keep the repo's desktop files unchanged.
- `Filee.slnx` is not updated here. Adding the project to the solution is a Phase 2 step on the feature branch.
- Repo CI workflows (`ci.yml`, `build.yml`, `portable.yml`) have no Android job. Android CI is new work.

## 7. Blockers and gate decision

- Critical architectural blocker: none for the managed-engine slice. Process-based engines need an Android-side replacement before they can be advertised.
- Critical build blocker in this environment: no .NET SDK, no Android workload, no package downloads. Phase 2 cannot be verified here.
- Gate result: **continue to Phase 2 on a feature branch**, with the first conversion slice restricted to managed and native-library engines that pass the Android test in Phase 4.

## 8. Recommended minimal vertical slice

1. Select one image through SAF (`ACTION_OPEN_DOCUMENT`).
2. Read it through the content URI.
3. Convert with one Android-verified engine (candidate: a managed or Skia-based path).
4. Write the output through SAF (`ACTION_CREATE_DOCUMENT`).
5. Open or share the result.
6. Record the job in Activity.

Each step should pass on a device before any second format is added.
