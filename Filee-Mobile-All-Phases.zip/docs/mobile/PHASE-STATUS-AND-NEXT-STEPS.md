# Filee Android: phase status and next steps

Baseline: `79f03bea1b93588002940812c45a7b8702a9a9f0` (main, read-only).
Target branch (not created here): `feat/filee-android`.

## Status by phase

| Phase | Blueprint exit criterion | Status | What exists | What is missing |
| --- | --- | --- | --- | --- |
| 1. Read-only audit | Documented audit, no repo modifications | **Done** | `PHASE1-AUDIT.md`. Repo untouched, HEAD verified. | Engine tests on Android (needs device) |
| 2. Android foundation | Mobile project builds without breaking desktop | **Authored, not built** | `src/Filee.Mobile/` project, app, activity, navigation shell | Compile; add to `Filee.slnx`; confirm desktop build unchanged; launch on emulator or device |
| 3. Mobile UI | All seven screens, bottom nav, theme, SAF picker | **Partial** | 5-tab bottom navigation, `MainViewModel` routing, theme follows system | Real screens for Home, Convert, Activity, Files, Settings; SAF picker; responsive layout at 320–412 dp; the 7th screen (File selection) is part of Convert |
| 4. Conversion integration | Every advertised conversion passes a real test | **Not started (blocked)** | `JobStateRules` (pure logic) and its unit tests | No engine verified on Android. Process-based engines need replacements. No conversion wired. |
| 5. Files and history | Output accessible through Android document APIs | **Not started** | None | Persistence, SAF output writing, open and share, delete with confirmation, temp cleanup |
| 6. Full validation | Automated and device tests pass | **Not started (blocked)** | `Filee.Mobile.Tests` (authored, not run) | Run tests; device tests; desktop regression; layout checks |
| 7. Release candidate | Verified installable debug APK | **Not started (blocked)** | Manifest properties in csproj (`ApplicationId`, version) | Build APK; install and launch; signing config kept out of the repo |

## Decisions made in this pass

1. **Scope:** Phases 1 to 3 are the realistic scope for this pass. Phases 4 to 7 need a toolchain and devices this environment does not have, so they are left open rather than claimed.
2. **Project location:** `src/Filee.Mobile/`, as the blueprint specifies. It is standalone and does not reference desktop projects.
3. **Central package management:** disabled locally in the mobile csproj. `Directory.Packages.props` is unchanged.
4. **Target framework:** `net10.0-android`, matching the SDK pin (`10.0.100`, `rollForward: latestFeature`). Avalonia `12.1.4` matches the desktop version.
5. **Job transitions:** Queued may be cancelled, and Preparing may fail. Blueprint Phase 4 requires interrupted jobs to be marked accurately, so this is a required transition. Please review.
6. **Filee.slnx and CI:** not modified. Both are Phase 2 work on the branch.

## Blocking items (needs your action or a different environment)

- Install the .NET 10 SDK and the Android workload on a machine that can reach NuGet, or allow package downloads for this account. Without this, nothing in `src/Filee.Mobile/` can be compiled or tested.
- A physical Android device is needed for Phase 6 and for the APK check in Phase 7. The blueprint's target is the iQOO Z10x.
- Licence review (see audit section 5) before any external engine is bundled.

## Future steps (in order)

1. **Create the branch** `feat/filee-android` from `79f03bea`. Apply `src/Filee.Mobile/` and `tests/Filee.Mobile.Tests/`. Do not commit to `main`.
2. **Build check:** run `dotnet build src/Filee.Mobile/Filee.Mobile.csproj -f net10.0-android` and `dotnet test tests/Filee.Mobile.Tests`. Fix compile errors. Record the actual output.
3. **Solution wiring:** add both projects to `Filee.slnx`. Confirm `dotnet build Filee.slnx` for the desktop projects is unchanged.
4. **Phase 3 screens:** replace the placeholder `TextBlock` in `MainView.axaml` with one view per tab, following the mockup. Build the Convert picker on SAF (`ACTION_OPEN_DOCUMENT`, multi-select). Add shared components: file row, job card, category chip, format picker sheet with search, engine badge, dialogs, snackbar.
5. **Platform services:** implement the `IPlatformServices` seams for Android: SAF read and write, app-private temp storage, share and open intents.
6. **Phase 4 vertical slice:** image to one verified converter, through SAF in and out, recorded in Activity. Only one engine. Test on a device before adding any other format.
7. **Engine replacements:** for each external-exe engine in the audit (C and D rows), decide: native Android build, managed replacement, or drop from the Android release. Record each decision.
8. **Phase 5:** persisted job history, output access through content URIs, delete with confirmation, missing-file handling, temp cleanup on success, failure, and cancel.
9. **Phase 6:** run all tests on a device. Add CI: an Android build job (new workflow file). Desktop regression stays on the existing workflows.
10. **Phase 7:** debug APK, then install and smoke test. Release signing stays out of the repo. No store upload or merge without your approval.

## Approval gates (do not skip)

- Merging into `main`, pushing to protected branches, publishing a release, uploading to a store: all need your explicit approval.
- Bundling any external engine: needs the licence review and your approval.
- Anything that sends user files to a remote service: needs a separate, disclosed, approved feature.

## Reporting rule

Every status line above is either "done", "authored, not built", or "not started". No phase is reported as passing until the build or test command has been run and its output recorded.
