using Filee.Mobile.Models;
using Xunit;

namespace Filee.Mobile.Tests;

public class JobStateRulesTests
{
    [Theory]
    [InlineData(JobState.Queued, JobState.Preparing)]
    [InlineData(JobState.Queued, JobState.Cancelled)]
    [InlineData(JobState.Preparing, JobState.Processing)]
    [InlineData(JobState.Preparing, JobState.Failed)]
    [InlineData(JobState.Preparing, JobState.Cancelled)]
    [InlineData(JobState.Processing, JobState.Completed)]
    [InlineData(JobState.Processing, JobState.Failed)]
    [InlineData(JobState.Processing, JobState.Cancelled)]
    public void AllowsDocumentedTransitions(JobState from, JobState to)
    {
        Assert.True(JobStateRules.CanTransition(from, to));
    }

    [Theory]
    [InlineData(JobState.Queued, JobState.Completed)]
    [InlineData(JobState.Queued, JobState.Processing)]
    [InlineData(JobState.Processing, JobState.Queued)]
    [InlineData(JobState.Completed, JobState.Processing)]
    [InlineData(JobState.Failed, JobState.Queued)]
    [InlineData(JobState.Cancelled, JobState.Processing)]
    public void RejectsIllegalTransitions(JobState from, JobState to)
    {
        Assert.False(JobStateRules.CanTransition(from, to));
    }

    [Theory]
    [InlineData(JobState.Completed)]
    [InlineData(JobState.Failed)]
    [InlineData(JobState.Cancelled)]
    public void TerminalStatesHaveNoExits(JobState state)
    {
        Assert.True(JobStateRules.IsTerminal(state));
        foreach (var target in Enum.GetValues<JobState>())
        {
            Assert.False(JobStateRules.CanTransition(state, target));
        }
    }

    [Theory]
    [InlineData(JobState.Queued)]
    [InlineData(JobState.Preparing)]
    [InlineData(JobState.Processing)]
    public void ActiveStatesAreNotTerminal(JobState state)
    {
        Assert.False(JobStateRules.IsTerminal(state));
    }
}
