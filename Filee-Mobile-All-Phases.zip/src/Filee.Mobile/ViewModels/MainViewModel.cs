using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Filee.Mobile.Models;

namespace Filee.Mobile.ViewModels;

public partial class MainViewModel : ObservableObject
{
    [ObservableProperty]
    private MobileTab _selectedTab = MobileTab.Home;

    /// <summary>Accepts the tab name as a string so XAML can pass it as a CommandParameter.</summary>
    [RelayCommand]
    private void SelectTab(string tabName) => SelectedTab = Enum.Parse<MobileTab>(tabName);
}
