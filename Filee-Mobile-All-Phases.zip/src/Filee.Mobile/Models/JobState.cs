namespace Filee.Mobile.Models;

/// <summary>Job states from blueprint section 3, screen 4.</summary>
public enum JobState
{
    Queued,
    Preparing,
    Processing,
    Completed,
    Failed,
    Cancelled,
}

/// <summary>
/// Legal state transitions. Terminal states (Completed, Failed, Cancelled) have no exits, so a finished job is
/// never reopened. Queued may be cancelled before it starts. Preparing may fail or be cancelled. Processing may
/// complete, fail, or be cancelled. Blueprint Phase 4 requires interrupted jobs to be recovered as Failed, not
/// Completed. The Queued/Preparing exits are decisions made in this scaffold and need review.
/// </summary>
public static class JobStateRules
{
    private static readonly IReadOnlyDictionary<JobState, JobState[]> Allowed = new Dictionary<JobState, JobState[]>
    {
        [JobState.Queued] = [JobState.Preparing, JobState.Cancelled],
        [JobState.Preparing] = [JobState.Processing, JobState.Failed, JobState.Cancelled],
        [JobState.Processing] = [JobState.Completed, JobState.Failed, JobState.Cancelled],
        [JobState.Completed] = [],
        [JobState.Failed] = [],
        [JobState.Cancelled] = [],
    };

    public static bool CanTransition(JobState from, JobState to) => Allowed[from].Contains(to);

    public static bool IsTerminal(JobState state) => Allowed[state].Length == 0;
}
