namespace Filee.Mobile.Models;

/// <summary>The five bottom-navigation destinations from the blueprint (section 3).</summary>
public enum MobileTab
{
    Home,
    Convert,
    Activity,
    Files,
    Settings,
}
