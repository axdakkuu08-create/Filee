# Filee Android phase pack

Contents of this pack, prepared from the Filee Mobile blueprint in Notion.

```
docs/mobile/PHASE1-AUDIT.md                  Phase 1 read-only audit (repo untouched)
docs/mobile/PHASE-STATUS-AND-NEXT-STEPS.md   Status per phase, blockers, future steps
src/Filee.Mobile/                            Phase 2 and 3 scaffold (authored, NOT compiled)
tests/Filee.Mobile.Tests/                    Job-state unit tests (authored, NOT run)
```

## How to use it

1. In a clone of `axdakkuu08-create/filee`, create the branch `feat/filee-android` from `79f03bea1b93588002940812c45a7b8702a9a9f0`. Do not use `main`.
2. Copy `src/Filee.Mobile/` and `tests/Filee.Mobile.Tests/` into the clone.
3. Build and test (needs .NET 10 SDK and the Android workload):
   - `dotnet test tests/Filee.Mobile.Tests`
   - `dotnet build src/Filee.Mobile/Filee.Mobile.csproj -f net10.0-android`
4. Record the real output. Do not report a pass that was not run.

## What is not included

- No changes to desktop projects, `Directory.Packages.props`, `Filee.slnx`, or CI workflows.
- No engine binaries, signing keys, or user files.
- No Android conversion. No engine has been verified on Android.

See `docs/mobile/PHASE-STATUS-AND-NEXT-STEPS.md` for the blockers and the order of work.
